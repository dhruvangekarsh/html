<header class="cd-header" style="position:fixed">
		<a class="cd-3d-nav-trigger">Menu<span></span></a>
	</header>
	
	<nav class="cd-3d-nav-container">
		<ul class="cd-3d-nav">
			<li class="cd-selected">
				<a href="index.php">Dashboard</a>
			</li>

			<li>
				<a href="projects.php">Projects</a>
			</li>

			<li>
				<a href="services.php">Services</a>
			</li>

			<li>
				<a href="#0">Settings</a>
			</li>

			<li>
				<a href="#0">New</a>
			</li>
		</ul>

		<span class="cd-marker color-1"></span>	
	</nav>