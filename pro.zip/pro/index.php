<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
	<link rel="stylesheet" type="text/css" href="css/jquery.fullPage.css" />
	<link rel="stylesheet" href="css/reset.css">
	<link rel="stylesheet" href="css/style.css">
	<script src="js/modernizr.js"></script>
</head>
<body>
	
<?php include './include/header.php'; ?>	

<div id="fullpage">
	<div class="section" id="section0">
		<div class="intro">
			<h1>One</h1>
		</div>
	</div>
	<div class="section" id="section1">
		<div class="intro">
			<h1>Two</h1>
		</div>
	</div>
	<div class="section" id="section2">
		<div class="intro">
			<h1>Three</h1>
		</div>
	</div>
</div>

<script src="js/jquery-2.1.4.js"></script>
<script src="js/menu.js"></script>
<script type="text/javascript" src="js/jquery.fullPage.js"></script>
	<script type="text/javascript">
		$(document).ready(function() {
			$('#fullpage').fullpage({
				sectionsColor: ['#999', '#999', '#999'],
				navigation: true,
				navigationPosition: 'right',
				navigationTooltips: ['First page', 'Second page', 'Third page']
			});
		});
	</script>

</body>
</html>