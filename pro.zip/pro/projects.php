<!doctype html>
<html lang="en" class="no-js">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<link href='https://fonts.googleapis.com/css?family=Fira+Sans:400,300,700' rel='stylesheet' type='text/css'>

	<link rel="stylesheet" href="css/reset.css">
	<link rel="stylesheet" href="css/slider.css">
	<link rel="stylesheet" href="css/style.css">
	<script src="js/modernizr.js"></script>
  	
	<title>Pointy Slider | CodyHouse</title>
</head>
<body>
	
	<?php include './include/header.php'; ?>
	
	<div class="cd-slider-wrapper">
		<ul class="cd-slider">
			<li class="is-visible">
				<div class="cd-half-block image"></div>

				<div class="cd-half-block content">
					<div>
						<h2>Pointy Slider</h2>
						<p>
							Lorem ipsum dolor sit amet, consectetur adipisicing elit. Repellat fugit ullam voluptatum tenetur ab, non beatae.
						</p>
						<a href="https://codyhouse.co/?p=7404" class="btn">Article &amp; Download</a>
					</div>
				</div>
			</li> 

			<li>
				<div class="cd-half-block image"></div>

				<div class="cd-half-block content light-bg">
					<div>
						<h2>Slide Number 2</h2>
						<p>
							Lorem ipsum dolor sit amet, consectetur adipisicing elit. Repellat fugit ullam voluptatum tenetur ab, non beatae, impedit dolorem itaque voluptates facilis necessitatibus suscipit dolor rerum dolores dignissimos alias facere sunt aliquid.
						</p>
					</div>
				</div> 
			</li>

			<li>
				<div class="cd-half-block image"></div>

				<div class="cd-half-block content">
					<div>
						<h2>Slide Number 3</h2>
						<p>
							Lorem ipsum dolor sit amet, consectetur adipisicing elit. Repellat fugit ullam voluptatum tenetur ab, non beatae, impedit dolorem itaque voluptates facilis necessitatibus suscipit dolor rerum dolores dignissimos alias facere sunt aliquid.
						</p>
					</div>
				</div>
			</li>

			<li>
				<div class="cd-half-block image"></div>

				<div class="cd-half-block content">
					<div>
						<h2>Slide Number 4</h2>
						<p>
							Lorem ipsum dolor sit amet, consectetur adipisicing elit. Repellat fugit ullam voluptatum tenetur ab, non beatae, impedit dolorem itaque voluptates facilis necessitatibus suscipit dolor rerum dolores dignissimos alias facere sunt aliquid.
						</p>
					</div>
				</div> 
			</li>
			
		</ul> 
	</div> 
	
<script src="js/jquery-2.1.4.js"></script>
<script src="js/jquery.mobile.custom.min.js"></script>
<script src="js/slider__main.js"></script>
<script src="js/menu.js"></script>
</body>
</html>